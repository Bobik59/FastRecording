﻿using ConsoleApp3.Model;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace ConsoleApp3
{
    public class RegistrationHub : Hub
    {
        private readonly BookingContext _context;

        public RegistrationHub(BookingContext context)
        {
            _context = context;
        }

        public async Task RegisterUser(string userType, string login, string password, string fio, string description)
        {
            try
            {
                using var transaction = await _context.Database.BeginTransactionAsync();

                var user = new User
                {
                    Login = login,
                    PasswordHash = PasswordHasher.Hash(password)
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                if (userType == "Мастер")
                {
                    var master = new Master
                    {
                        UserId = user.Id,
                        FIO = fio,
                        Description = description
                    };
                    _context.Masters.Add(master);
                }
                else
                {
                    var client = new Client
                    {
                        UserId = user.Id,
                        FIO = fio
                    };
                    _context.Clients.Add(client);
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                await Clients.Caller.SendAsync("RegistrationStatus", true, "Регистрация успешна!");
            }
            catch (DbUpdateException ex)
            {
                await Clients.Caller.SendAsync("RegistrationStatus", false, "Ошибка: Логин уже занят.");
            }
            catch (Exception ex)
            {
                await Clients.Caller.SendAsync("RegistrationStatus", false, $"Ошибка: {ex.Message}");
            }
        }
    }
}